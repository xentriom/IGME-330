export enum ToggleButtons {
    PLAY = "https://c.animaapp.com/fgpR59jS/img/svgexport-35--1--1@2x.png",
    PAUSE = "https://c.animaapp.com/yPlj5CdF/img/svgexport-83-1.svg"
}