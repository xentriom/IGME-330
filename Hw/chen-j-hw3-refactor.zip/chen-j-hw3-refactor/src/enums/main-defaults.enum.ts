export enum DEFAULTS {
    sound1 = "./assets/audio/Passing Memories.mp3"
}