export enum Defaults {
    SOUND_ONE = "./assets/audio/Passing Memories.mp3"
}