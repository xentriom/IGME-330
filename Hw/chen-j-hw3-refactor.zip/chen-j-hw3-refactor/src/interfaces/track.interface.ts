export interface Track {
    name: string;
    author: string;
    image: string;
    path: string;
}