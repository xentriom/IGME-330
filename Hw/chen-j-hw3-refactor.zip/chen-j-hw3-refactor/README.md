<h1 align="center">Audio Visualizer</h1>
