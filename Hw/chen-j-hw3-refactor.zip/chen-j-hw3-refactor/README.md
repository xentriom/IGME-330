<h1 align="center">Audio Visualizer</h1>
https://people.rit.edu/jc5892/av
