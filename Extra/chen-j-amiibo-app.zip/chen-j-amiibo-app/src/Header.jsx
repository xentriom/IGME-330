export const Header = () => {
    return (
        <header>
            <h1>Amiibo App</h1>
        </header>
    );
}